import { CurrencyPipePipe } from './currency-pipe.pipe';

describe('CurrencyPipePipe', () => {
  it('create an instance', () => {
    const pipe = new CurrencyPipePipe();
    expect(pipe).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  navigateUrl:string="http://localhost:3000/Customer_Details";
  constructor(private http:HttpClient) { }

  getData(){
    return this.http.get(this.navigateUrl);
  }
}

import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Acc } from '../acc';

@Injectable({
  providedIn: 'root'
})
export class AccountCurrService {
  txtCurr:string='';
 navigateUrl:string="http://localhost:3000/CurrencyJson";
  Banned_Currency: string='';
  constructor(private http:HttpClient) { }
  
  getDetails():Observable<Acc[]>{
    return this.http.get<Acc[]>(this.navigateUrl);
  }
  setData(accObserve:Acc):Observable<Acc>
  {
    return this.http.post<Acc>(this.navigateUrl,accObserve);
  }
}



import { Component } from '@angular/core';
import { CustomerService } from './service/customer.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PromiseExercise';
  str="Brown Cony";
  constructor(private cusData:CustomerService){
  this.cusData.getData().toPromise().then((data)=>{console.log(data)});
  }
 
}

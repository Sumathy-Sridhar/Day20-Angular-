import { Component } from '@angular/core';
import { Acc } from './acc';
import { AccountCurrService } from './service/account-curr.service';
import {map} from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ObservableMap';
  constructor(private accServ:AccountCurrService){
  }
  id:string='';
  Banned_Currency:string='';
  Amount_Limit:number=0;
  Blocked_Account:number=0;
  Expiry_Date:string='';
  entCurr:string='';
  
  acc:Acc | undefined;
  accArr:Acc[] | undefined; 
  postData()
  {
    this.acc=new Acc(this.id,this.Banned_Currency,this.Amount_Limit,this.Blocked_Account,this.Expiry_Date);
    this.accServ.setData(this.acc).subscribe((data)=>
    {
      console.log(data)
    });
  }
  getFullData(){
    this.accServ.getDetails().subscribe((data)=>{console.log(data)});
  }
  getData(entCurr:string)
  {
    this.accServ.getDetails().pipe(
      map(data=>data.filter(d=>d.Banned_Currency!=entCurr))).subscribe((data:any)=>
    {
      this.accArr=data;
    });
  }
}

function data(data: any) {
  throw new Error('Function not implemented.');
}

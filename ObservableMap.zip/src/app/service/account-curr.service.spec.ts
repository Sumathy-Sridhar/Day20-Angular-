import { TestBed } from '@angular/core/testing';

import { AccountCurrService } from './account-curr.service';

describe('AccountCurrService', () => {
  let service: AccountCurrService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccountCurrService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

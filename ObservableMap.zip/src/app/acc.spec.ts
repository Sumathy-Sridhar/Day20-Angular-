import { Acc } from './acc';

describe('Acc', () => {
  it('should create an instance', () => {
    expect(new Acc()).toBeTruthy();
  });
});

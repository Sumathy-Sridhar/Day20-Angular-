export class Acc {
    id:string='';
    Banned_Currency:string='';
    Amount_Limit:number=0;
    Blocked_Account:number=0;
    Expiry_Date:string='';
    constructor(id:string,Banned_Currency:string,Amount_Limit:number,Blocked_Account:number,Expiry_date:string){
        this.id=id;
        this.Banned_Currency=Banned_Currency;
        this.Amount_Limit=Amount_Limit;
        this.Blocked_Account=Blocked_Account;
        this.Expiry_Date=Expiry_date;
    }
}
